
[Unity 2018.2.3f1]: https://unity3d.com/unity/whatsnew/unity-2018.2.3
[Unity Download Archive]: https://unity3d.com/get-unity/download/archive
[Android SDK/NDK setup]: https://docs.unity3d.com/Manual/android-sdksetup.html
[lxvr-sdk_unity.unitypackage]: http://looxidlabs.com/looxidvr/docs/unity-sdk/releases
[Quickstart for Google VR SDK for Unity with Android]: https://developers.google.com/vr/develop/unity/get-started-android

# **LooxidVR SDK for Unity**

This manual explains how to download LooxidVR SDK for Unity, follow the tutorials, and execute them.  


# 1. Quickstart for LooxidVR SDK for Unity with Android

## 1.1 Set up your development environment

*   Hardware requirements:
    *   LooxidVR-compatible mobile phone
    *   LooxidVR Headset & EEG Mask
*   Software requirements:
    *   Unity: [Unity 2018.2.3f1] or newer (Download at [Unity Download Archive])
    *   Make sure that the Android Build Support component is selected during installation.   
    ![](lxvr-sdk_img/LooxidVR-SDK0.png "")

    *   Make sure your environment is configured for Android development. Refer to Unity's guide for [Android SDK/NDK setup].


## 1.2 Download the LooxidVR SDK for Unity

Download the latest [lxvr-sdk_unity.unitypackage] from Releases.


## 1.3 Create a new Unity project and import the LooxidVR Unity package

1.  Open Unity and create a new 3D project.   
1.  Select Assets > Import Package > Custom Package.   
1.  Select the LooxidVR Unity package file that you downloaded.   
1.  In the Importing Package dialog, click Import.   
![](lxvr-sdk_img/LooxidVR-SDK1.png "")


## 1.4 Components

The basic components of SDK are the following:   
![](lxvr-sdk_img/LooxidVR-SDK2.png "")   
   
1.  **LXVR-SDK-UNITY_API-Doc.zip**: Document with the API of Unity-SDK  
1.  **README.zip**: The current document that is being read
1.  **LXVRManager.prefab**: Prefab for running LXVRManager.cs. LXVRManager.cs is Singleton, so you can call it from anywhere.
1.  **Tutorial1.unity**: The basic scene for Tutorial 1
1.  **Tutorial2.unity**: The basic scene for Tutorial 2


## 1.5 Set up Google VR development environment

See [Quickstart for Google VR SDK for Unity with Android].   
LooxidVR SDK for Unity already contains Google VR SDK for Unity so skip the import step. 


# 2. Tutorial 1

## 2.1 Open Tutorial 1

On the Project tab, double click  **Assets > Tutorials > Tutorial1 > Tutorial1.unity** to load the scene.   
![](lxvr-sdk_img/LooxidVR-SDK3.png "")


## 2.2 Set LXVRManager.prefab

Tutorial1.unity is a scene that already contains LXVRManager. To configure the LXVRManager in the scene, follow the steps below:

1.  Put **LXVRManager.prefab** in to the scene.   
1.  **LXVRManager** GameObject is DontDestroyOnLoad object.   


## 2.3 LXVRManager.cs   
![](lxvr-sdk_img/LooxidVR-SDK4.png "")   

1.  **Is Debug**: Switch for printing log to the console 
1.  **Broadcasting On Awake**: Switch that initiates broadcasting in order to connect LooxidVR SDK-linked app to LooxidVR Application on the same network when the SDK-linked app awakes
1.  **User ID**: User ID to identify the subject in an experiment
1.  **Experiment Name**: Experiment name to identify experiment
1.  **Vr Controller GO**: Game Object for turning off the pointer during eye-tracking calibration


## 2.4 Initialize LXVRManager

**Tutorial1.cs** contains the process of utilizing LXVRManager.

*   Initialization is required to use LXVRManager. 
*   LXVRManager is a Singleton object that can be called anywhere.

```csharp
public void Init()
{
    LXVRManager = LXVRManager.Instance;
    LXVRManager.connectionStatusCallback = OnConnectStatusCallback;
    LXVRManager.lxvrStatusChangedCallback = OnStatusChanged;
}

public void OnConnectStatusCallback(ConnectionStatus connectionStatus)
{
    Debug.Log("OnConnectStatusCallback : " + connectionStatus);
    // Do something..._
}

public void OnStatusChanged(LXVRStatus status)
{
    Debug.Log("OnStatusChanged");
    Debug.Log("------> coreStatus " + status.coreStatus);
    Debug.Log("------> eegSensor " + status.eegSensorStatus);
    Debug.Log("------> eyeCamera " + status.eyeCameraStatus);
    // Do something…
}
```

Before connecting to LooxidVR application, the first things to initialize in LXVRManager are two callbacks. Callback handler can also be configured as above. Depending on the state of the connection, you can start / stop / resume the experiment.

*   **connectionStatusCallback**: Called when there is a change in the state of the connected device in the application.
*   **lxvrStatusChangedCallback**: Called when there is a change in the state of the connected device in the application.
    *   **LXVRStatus** can be used to determine the status of LooxidVR Application and connected devices.
    *   If you have trouble with the connection, you may need to choose to stop or end the experiment.
    *   Specific details of **LXVRStatus** can be found at Etc.>Get Current Data.


## 2.5 Initialize GoogleVR SDK

Add GoogleVR prefabs to your scene.   
![](lxvr-sdk_img/LooxidVR-SDK5.png "")

*   **GvrInstantPreviewMain**: (Optional) Allows you to test on mobile without having to install the app on your mobile device.
*   **GvrControllerMain**: Required for using the GoogleVR controller API.
*   **GvrEventSystem**: Contains the GvrPointerInputModule, replacing Unity's EventSystem.
*   **GvrEditorEmulator**: (Optional) Emulates the motion of the mobile device on the Unity editor.
*   **GvrControllerPointer**: Tells the screen to use the GoogleVR controller.


## 2.6 Development

Let's look at how to call Eye Calibration and Device Status Panel using LXVRManager.



1.  Create two clickable buttons.
1.  To open the Device Status panel, add the Tutorial1.OpenDeviceStatusPanel to the first Button's On Click () event handler and connect.
1.  To perform the eye calibration, add the Tutorial1.OpenEyeTrackingCalibrationPanel to the second Button's On Click () event handler and connect.

```csharp
public void OpenDeviceStatusPanel(
{
    bool isOpened = LXVRManager.OpenDeviceStatusPanel();
    Debug.Log("OpenDeviceStatusPanel : " + isOpened);
}

public void OpenEyeCalibration()
{
    LXVRDelegate eyeTrackingCalibrationPanelClosed = () =>
    {
        Debug.Log("eyeTrackingCalibrationPanelClosed");
    };

    bool isOpened = LXVRManager.OpenEyeTrackingCalibrationPanel(eyeTrackingCalibrationPanelClosed);
    Debug.Log("OpenEyeCalibration : " + isOpened);
}
```


*   **OpenDeviceStatusPanel**
    *   The **OpenDeviceStatusPanel** returns whether the Device Status Panel has been successfully opened.
    *   Depending on the connection status of the device, the Device Status window may not open.
*   **OpenEyeTrackingCalibrationPanel**
    *   The **OpenEyeTrackingCalibrationPanel** tells when to close the calibration window after completing calibration through callback.
    *   After the calibration is complete, you can proceed with the experiment.


## 2.7 Build

Configure the following player settings:


<table>
  <tr>
   <td>Setting
   </td>
   <td>Value
   </td>
  </tr>
  <tr>
   <td>Player Settings > XR Settings > Virtual Reality Supported
   </td>
   <td>Enabled
   </td>
  </tr>
  <tr>
   <td>Player Settings > XR Settings > Virtual Reality SDKs
   </td>
   <td>Click + and select Daydream
   </td>
  </tr>
  <tr>
   <td>Player Settings > Other Settings > Minimum API Level
   </td>
   <td>Android 7.0 'Nougat' (API level 24) or higher.
   </td>
  </tr>
</table>




1.  Select **File > Build Settings**.
1.  Select Android and click Switch Platform.
1.  In the Build Settings window, click Player Settings.
1.  Connect your phone to your computer using a USB cable.
1.  Select **File > Build** and Run.
1.  Unity builds your project into an Android APK, installs it on the device, and launches it.


## 2.8 Run & Connect

1.  When you execute Tutorial 1 in Unity, it will show a "waiting to connect" screen as follows. LXVRManager broadcasts its "Connection Ready" status while waiting for the connection.   
![](lxvr-sdk_img/LooxidVR-SDK6.png "")   

1.  Run the LooxidVR application first, then click the Connect App button on the app.   
![](lxvr-sdk_img/LooxidVR-SDK7.png "")

1.  You can see which computer is running the experimental app that is currently broadcasting the "Connection Ready" state. If you select and click on the experiment app you want to connect to, the connection will be made.   
![](lxvr-sdk_img/LooxidVR-SDK8.png "")

1.  Once the connection is complete, the Connect App button disappears and the "Waiting" state in the experiment app disappears as well.   
![](lxvr-sdk_img/LooxidVR-SDK9.png "")   
![](lxvr-sdk_img/LooxidVR-SDK10.png "")   


## 2.9 Test

1.  You can activate the emulated Google VR pointer by pressing the Shift button and moving the mouse.   
1.  When you click the Device Status button with the pointer, a UI is. displayed to check the Device Status.   
![](lxvr-sdk_img/LooxidVR-SDK11.png "")   

1.  If you click the Eye Calibration button with the pointer, you can proceed with the Eye Calibration.   
![](lxvr-sdk_img/LooxidVR-SDK12.png "")   


# 3. Tutorial 2

Use LooxidVR SDK to record EEG and gaze data at desired points and to record event log.


## 3.1 Open Tutorial 2

In the Project window, double-click Assets> Tutorials> Tutorial2> Tutorial2.unity to load the scene.   
![](lxvr-sdk_img/LooxidVR-SDK13.png "")   


## 3.2 Set LXVRManager.prefab

Refer to Tutorial 1 > Set LXVRManager.prefab.


## 3.3 Initialize LXVRManager

Tutorial1.cs is replaced with Tutorial2.cs and the configuration is the same as in Tutorial 1 > Initialize LXVRManager.


## 3.4 Initialize GoogleVR SDK

Refer to Tutorial1 > Initialize GoogleVR SDK.


## 3.5 Development

1.  Configure the desired screen.
1.  For initialization of LXVRManager, refer to Development in Tutorial 1.
1.  For more information about using RecordingStart, see the **public void ChangeMode(Tutorial2Status status)** function in **Tutorial2.cs** file which is included in the SDK.
1.  For more information about using RecordingEvent, see the **private void SetQuestion(int questionNo) function** in **Tutorial2.cs** file which is included in the SDK.


## 3.6 Recording

The basic recording method is as follows. In one experiment, use **SESSION_NAME** and **TRIAL_NAME** to distinguish your recordings. (**SESSION_NAME** is a parent category of **TRIAL_NAME**.)


### 3.6.1 Recording Start

```csharp
LXVRDelegate resultSuccessCallback = () =>
{
    Debug.Log("RecordingStart resultSuccessCallback : ");
};

LXVRDelegate resultFailCallback = () =>
{
    Debug.Log("RecordingStart resultFailCallback : ");
};

LXVRManager.RecordingStart("SESSION_NAME",
                           "TRIAL_NAME",
                           true,    // if you put true, it records with video
                           resultSuccessCallback,
                           resultFailCallback);
```

LXVRManager.RecordingStart() accepts a video recording option as a parameter in addition to SESSION_NAME and TRIAL_NAME. You can also add a callback that is called when the start-of-recording action is successful and when it fails.


### 3.6.2 Recording Stop

```csharp
LXVRDelegate resultSuccessCallback = () =>
{
    Debug.Log("RecordingStop resultSuccessCallback : ");
};

LXVRDelegate resultFailCallback = () =>
{
    Debug.Log("RecordingStop resultFailCallback : ");
};

LXVRManager.RecordingStop("SESSION_NAME",
                          "TRIAL_NAME",
                          resultSuccessCallback,
                          resultFailCallback);
```

After the recording starts, you must call end to end the recording. You can also add callbacks that are called upon success or failure of the end-of-recording action.


### 3.6.3 Recording Event

You can record specific events during the recording process. By default, the event contains the time of occurrence. In other words, when invoked during recording, the timestamp and details of the event are recorded. When the recording operation succeeds or fails, the RecordingEvent function calls the corresponding callbacks.

```csharp
//Event details can be written in json format.
//All events are saved along with timestamp._
var customEvent = new CustomEvent
{
    UserAnswer = 0,
    OriginalAnswer = 1,
    Correct = false,
    Level = "easy"
};
string customEventDetail = JsonUtility.ToJson(customEvent);

LXVRDelegate resultSuccessCallback = () =>
{
    Debug.Log("RecordingEvent resultSuccessCallback : ");
};

LXVRDelegate resultFailCallback = () =>
{
    Debug.Log("RecordingEvent resultFailCallback : ");
};

LXVRManager.RecordingEvent("SESSION_NAME",
                           "TRIAL_NAME",
                           customEventDetail,
                           resultSuccessCallback,
                           resultFailCallback);
```


## 3.7 Build

Refer to Tutorial 1 > Build. 


## 3.8 Run & Connect

Refer to Tutorial 1 > Run & Connect.


## 3.9 Test

1.  You can activate the emulated Google VR pointer by pressing the Shift button and moving the mouse.   
1.  Press the Start Test button. At this time, the button does not work if it is not connected to the LooxidVR application.   
![](lxvr-sdk_img/LooxidVR-SDK14.png "")   

1.  If you press the button while connected to the LooxidVR application, the Eye Calibration Panel will open.   
![](lxvr-sdk_img/LooxidVR-SDK15.png "")

1.  After the eye calibration process, one image at a time will be displayed on screen for 5 seconds each for 8 images in succession. EEG and gaze data are recorded while the images are shown.   
![](lxvr-sdk_img/LooxidVR-SDK16.png "")

1.  After all the images have come out, the first survey questionnaire appears.   
![](lxvr-sdk_img/LooxidVR-SDK17.png "")

1.  The selected option is passed unto the LooxidVR application, and then moves onto the video playback phase, which is LooxidVR introduction video.   
![](lxvr-sdk_img/LooxidVR-SDK18.png "")

1.  When the video is finished, the second survey questionnaire appears.   
![](lxvr-sdk_img/LooxidVR-SDK19.png "")

1.  It is configured to quit when you finish the second survey questionnaire.   
![](lxvr-sdk_img/LooxidVR-SDK20.png "")


# 4. Etc.

## 4.1 Menu

### 4.1.1 Open/Close Main Menu

```csharp
// Open device menu panel
bool isOpened = LXVRManager.OpenDeviceStatusPanel();

// Close device menu panel
LXVRManager.CloseMenuPanel();
```

Call Main Menu to access Device Status and Calibration. The bool value returned tells you if the Main Menu call succeeded.


### 4.1.2 Open/Close Device Status Menu

```csharp
// Open device status panel
bool isOpened = LXVRManager.OpenDeviceStatusPanel();

// Close device status panel
LXVRManager.CloseDeviceStatusPanel();
```

Call the Device Status Panel without accessing the Main Menu. The bool value returned indicates whether the Device Status Panel call succeeded.


## 4.2 Get Current Data

### 4.2.1 Status

Unity can read the data currently being measured on the device. This data is accessible via LXVRData.

```csharp
public static class LXVRData
{
    public static LXVRStatus status;

    public static Vector2 GetGazePosition()
    { ... }
    public static GazeDirection GetGazeDirection()
    { ... }
    public static EEGSensor GetEEGSensor(EEGSensorID eegSensorID)
    { ... }
}
```

*   **LXVRStatus status**: Indicates the status of the LooxidVR application.
*   **GetGazePosition()**: Returns the current gaze position value.
*   **GetGazeDirection()**: Returns the current gaze direction value.
*   **GetEEGSensor(EEGSensorID eegSensorID)**: Represents an EEG sensor object.

```csharp
public struct LXVRStatus
{
    public ConnectionStatus connectionStatus;
    public EEGSensorStatus eegSensorStatus;
    public EyeCameraStatus eyeCameraStatus;
}
```

*   **public ConnectionStatus connectionStatus**: Indicates the connection status with the LooxidVR application.
*   **public EEGSensorStatus eegSensorStatus**: Indicates the connection status of the EEG sensor.
*   **public EyeCameraStatus eyeCameraStatus**: Indicates the connection status of the eye camera.


### 4.2.2 Gaze Direction

Unity can read the gaze direction currently being measured on the device.

```csharp
GazeDirection LXVRData.GetGazeDirection();
public struct GazeDirection
{
    public float azimuth;
    public float elevation;
}
```
GazeDirection has the following information.

*   azimuth: Refers to the horizontal angle of gaze.
*   elevation: Refers to the vertical angle of gaze.


### 4.2.3 Get EEG data

Each position of the EEG sensor and its corresponding ID is as follows:   
![](lxvr-sdk_img/LooxidVR-SDK21.png "")

You can use **LXVRData.GetEEGSensor()** to retrieve data from the EEG sensor.   
```csharp
public enum EEGSensorID
{
    AF3 = 0,
    AF4,
    FP1,
    FP2,
    AF7,
    AF8
}

EEGSensor LXVRData.GetEEGSensor(EEGSensorID.AF3);
```

The structure is as follows.

```csharp
public struct EEGSensor
{
    public EEGSensorPointStatus SensorStatus
    public double[] rawEEGDataPerFreqArray;
    public double MinAlpha;
    public double MaxAlpha;
    public double Alpha;
    public double MinBeta;
    public double MaxBeta;
    public double Beta;
}
```

*   **public EEGSensorPointStatus SensorStatus**: The state of the EEG sensor.
*   **public double[] rawEEGDataPerFreqArray**: The power spectral density in the range of 1~46Hz, which is measured by EEG sensor.
*   **public double MinAlpha**:  The minimum value of the last 10 frames among 8~12Hz Alpha waves.
*   **public double MaxAlpha**: The maximum value of the last 10 frames among 8~12Hz Alpha waves.
*   **public double Alpha**: The average value of the last 10 frames among 8~12Hz Alpha waves.
*   **public double MinBeta**: The minimum value of the recent 10 frames among 13~30Hz Beta waves.
*   **public double MaxBeta**: The maximum value of the last 10 frames among 13~30Hz Beta waves.
*   **public double Beta**: The average value of the last 10 frames among 13~30Hz Beta waves.

<!-- GD2md-html version 1.0β13 -->
