var searchData=
[
  ['lxvrstatuschangedcallback',['lxvrStatusChangedCallback',['../class_looxid_1_1_l_x_v_r_manager.html#ab5f6e9674a699df130c69af2a43de499',1,'Looxid::LXVRManager']]]
];
