var searchData=
[
  ['disconnect',['Disconnect',['../class_looxid_1_1_l_x_v_r_manager.html#af7240e4a660f6ed48edf2cd1c836b210',1,'Looxid::LXVRManager']]],
  ['discoveritemlist',['DiscoverItemList',['../class_looxid_1_1_l_x_v_r_manager.html#a755c1165379c2188706c18c61747d7f2',1,'Looxid::LXVRManager']]]
];
