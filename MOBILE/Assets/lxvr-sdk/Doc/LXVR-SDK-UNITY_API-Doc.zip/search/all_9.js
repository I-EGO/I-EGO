var searchData=
[
  ['startbroadcasting',['StartBroadCasting',['../class_looxid_1_1_l_x_v_r_manager.html#a5538b036aded5be8a147b4fa4800bde1',1,'Looxid::LXVRManager']]],
  ['stopbroadcasting',['StopBroadCasting',['../class_looxid_1_1_l_x_v_r_manager.html#a1a21a874b0fea3a0678faae045b86d13',1,'Looxid::LXVRManager']]]
];
