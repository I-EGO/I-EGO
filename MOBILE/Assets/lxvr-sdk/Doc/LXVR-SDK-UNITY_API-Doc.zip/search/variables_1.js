var searchData=
[
  ['connectionstatuscallback',['connectionStatusCallback',['../class_looxid_1_1_l_x_v_r_manager.html#ad0b636b6d27c3fbc99b3ae2c3a302983',1,'Looxid::LXVRManager']]]
];
